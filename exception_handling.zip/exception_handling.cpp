// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>
#include <exception>
#include <string>

// Custom exception class derived from std::exception
class CustomException : public std::exception {
public:
    const char* what() const noexcept override {
        return "Custom Exception occurred!";
    }
};

//function that throws a standard exception
bool do_even_more_custom_application_logic()
{
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    throw std::runtime_error("Standard exception thrown in do_even_more_custom_application_logic");

    return true;
}


void do_custom_application_logic() {
    // Wrapping the call to do_even_more_custom_application_logic with exception handling
    try {
        std::cout << "Running Custom Application Logic." << std::endl;
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex) {
        // Catching the standard exception and displaying a message
        std::cout << "Caught an exception in do_custom_application_logic: " << ex.what() << std::endl;
    }

    // Throwing a custom exception
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl;
};


// Function that performs division and handles divide-by-zero errors
float divide(float num, float den) {
    if (den == 0) {
        // Throwing a standard exception for divide-by-zero
        throw std::invalid_argument("Division by zero error!");
    }
    return (num / den);
};

void do_division() noexcept {
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex) {
        std::cout << "Caught an exception in do_division: " << ex.what() << std::endl;
    }
};

int main() {
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // Calling functions to demonstrate exception handling
        do_division();
        do_custom_application_logic();
        do_even_more_custom_application_logic();

    }
    catch (const CustomException& ex) {
        // Catching the custom exception
        std::cout << "Caught a custom exception in main: " << ex.what() << std::endl;
    }
    catch (const std::exception& ex) {
        // Catching standard exceptions
        std::cout << "Caught a standard exception in main: " << ex.what() << std::endl;
    }
    catch (...) {
        // Catching all other unhandled exceptions
        std::cout << "Caught an unknown exception in main." << std::endl;
    }

    return 0;
}
// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu