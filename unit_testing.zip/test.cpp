// Uncomment the next line to use precompiled headers
#include "pch.h"
#include <vector>
#include <stdexcept>
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
//    FAIL();
//}

// Verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector) {
    collection->push_back(10);
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 1);
    EXPECT_EQ(collection->at(0), 10);
}

// Verify adding five values to the collection
TEST_F(CollectionTest, CanAddFiveValuesToVector) {
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);
}

// test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualSize) {
    std::vector<int> vec;
    for (int size : {0, 1, 5, 10}) {
        vec.resize(size);
        EXPECT_GE(vec.max_size(), vec.size());
    }
}

//test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanOrEqualSize) {
    std::vector<int> vec;
    for (int size : {0, 1, 5, 10}) {
        vec.resize(size);
        EXPECT_GE(vec.capacity(), vec.size());
    }
}

// test to verify resizing increases the collection size
TEST_F(CollectionTest, ResizeIncreasesCollection) {
    collection->resize(10);
    ASSERT_EQ(collection->size(), 10);
}

// test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection) {
    collection->resize(10);
    collection->resize(5);
    ASSERT_EQ(collection->size(), 5);
}

// TODO: test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero) {
    collection->resize(10);
    collection->resize(0);
    ASSERT_EQ(collection->size(), 0);
}

//test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection) {
    add_entries(5);
    collection->clear();
    ASSERT_TRUE(collection->empty());
}

// test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseRemovesCollection) {
    add_entries(5);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->empty());
}

// test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize) {
    collection->reserve(20);
    EXPECT_GE(collection->capacity(), 20);
    EXPECT_EQ(collection->size(), 0);
}

// test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
//NEGATIVE TEST
TEST_F(CollectionTest, OutOfRangeException) {
    add_entries(5);
    EXPECT_THROW(collection->at(10), std::out_of_range);
}

// Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// Custom Positive Test: Verify values remain after adding them sequentially
TEST_F(CollectionTest, ValuesPersistAfterInsertion) {
    collection->push_back(42);
    collection->push_back(99);
    ASSERT_EQ(collection->size(), 2);
    EXPECT_EQ(collection->at(0), 42);
    EXPECT_EQ(collection->at(1), 99);
}

// Custom Negative Test: Verify exception when popping from empty vector
TEST_F(CollectionTest, PopBackOnEmptyCollection) {
    // Ensure collection is empty
    ASSERT_TRUE(collection->empty());

    // Call pop_back only if it's not empty
    if (!collection->empty()) {
        collection->pop_back();
    }

    // The test passes if no exception or assertion is triggered
    ASSERT_TRUE(collection->empty());
}